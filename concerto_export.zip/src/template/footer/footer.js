testRunner.controllerProvider.register("footer", function($scope) {
  $scope.footer = testRunner.R.footer;
});
