testRunner.controllerProvider.register("testKanji", function ($scope) {
  $scope.items = testRunner.R.items;
  console.log($scope.items);
  $scope.canGoBack = testRunner.R.canGoBack == 1;
  $scope.responseRequired = testRunner.R.responseRequired == 1;
  $scope.responseRequiredAlert = testRunner.R.responeRequiredAlert;
  $scope.page = testRunner.R.page;
  $scope.totalPages = testRunner.R.totalPages;
  $scope.pastResponses = testRunner.R.responses;
  $scope.responses = {};
  $scope.nextButtonLabel = testRunner.R.nextButtonLabel;
  $scope.backButtonLabel = testRunner.R.backButtonLabel;
  $scope.showPageInfo = testRunner.R.showPageInfo == 1;
  
  $scope.isFormValid = function() {
    if(!$scope.responseRequired) {
      return true;
    }
    for(let i=0; i<$scope.items.length; i++) {
      let item = $scope.items[i];
      let response = $scope.responses["r" + item.id];
      if(response.skipped) continue;
      if(!response.isValid()) return false;
    }
    return true;
  }
  
  for (let i = 0; i < $scope.items.length; i++) {
    let item = $scope.items[i];
    /*if (typeof item.responseOptions === "string") {
      item.responseOptions = JSON.parse(item.responseOptions);
    }*/
    if (typeof $scope.responses["r" + item.id] === 'undefined') {
      $scope.responses["r" + item.id] = {
        skipped: 0
      };
    }
    
    $scope.responses["r" + item.id].isValid = function() {
      return typeof this.value !== 'undefined' && this.value !== null && this.value !== ""; 
    }
    
    testRunner.addExtraControl("skip"+item.id, function() {
      return $scope.responses["r"+item.id].skipped;
    });
  }
    
/*var responseFields = new Map(); // Map to store response fields and their corresponding Sets of options 
var optionPoolContainer = document.getElementById('optionPool');
var wordListContainer = document.getElementById('wordList');
    
function addOption(item) {
    var optionKanji = document.createElement('div');
    optionKanji.classList.add('option');
    optionKanji.draggable = 'true';
    optionKanji.id = 'optionKanji' + item.id;
    optionKanji.textContent = item.responseLabel1;

    var optionKana = document.createElement('div');
    optionKana.classList.add('option');
    optionKana.draggable = 'true';
    optionKana.id = 'optionKana' + item.id;
    optionKana.textContent = item.responseLabel1;

    // Attach drag event listeners to options
    optionKanji.addEventListener('dragstart', drag);
    optionKana.addEventListener('dragstart', drag);

   	optionPoolContainer.appendChild(optionKanji);
    optionPoolContainer.appendChild(optionKana);
  
  	var unmatchedOptionSet = responseFields.get(optionPoolContainer, unmatchedOptionSet);
    unmatchedOptionSet.add(optionKanji);
    unmatchedOptionSet.add(optionKana);
}
    
function addItem(item) {
    console.log($scope.item);
    var wordItem = document.createElement('div');
    wordItem.classList.add('wordItem');

    var translation = document.createElement('div');
    translation.classList.add('translation');
    translation.textContent = item.question;

    var kanjiResponse = document.createElement('div');
    kanjiResponse.classList.add('response');
    kanjiResponse.setAttribute('ondrop', 'drop(event)');
    kanjiResponse.setAttribute('ondragover', 'allowDrop(event)');
    kanjiResponse.maxChildren = 1;
    kanjiResponse.id = "responseKanji" + item.id;
    
    var kanaResponse = document.createElement('div');
    kanaResponse.classList.add('response');
    kanaResponse.setAttribute('ondrop', 'drop(event)');
    kanaResponse.setAttribute('ondragover', 'allowDrop(event)');
    kanaResponse.maxChildren = 1;
    kanaResponse.id = "responseKana" + item.id;

    wordItem.appendChild(translation);
    wordItem.appendChild(kanjiResponse);
    wordItem.appendChild(kanaResponse);
    wordListContainer.appendChild(wordItem);
 }
    
function allowDrop(event) {
  event.preventDefault();
}

function drag(event) {
  console.log("dragging element " + event.target.id);
  event.dataTransfer.setData("text/plain", event.target.id); // Set the dragged element's ID as the data
}

function drop(event) {
  event.preventDefault();
  console.log('Dragged element ID:', event.dataTransfer.getData("text/plain")); // Debugging: Log the ID of the dragged element
  var data = event.dataTransfer.getData("text/plain");
  var draggedElement = document.getElementById(data); // Get the dragged element using its ID
  console.log('Dragged element:', draggedElement); // Debugging: Log the dragged element
  
  // Check if the response field already contains a child element
  var dropField = event.target;
  console.log("dropping into: " + dropField);
  var optionsInField = responseFields.get(dropField);
  console.log(optionsInField);
  console.log("size: " + optionsInField.size);
  console.log("max: " + dropField.maxChildren);
  if (optionsInField.size < dropField.maxChildren) { 
    if (responseFields.get(draggedElement.parentElement) != null) {
      console.log(responseFields.get(draggedElement.parentElement));
     	let parentSet = responseFields.get(draggedElement.parentElement);
        parentSet.delete(draggedElement);
      	responseFields.set(draggedElement.parentElement, parentSet);
    }
    dropField.appendChild(draggedElement);
    optionsInField.add(draggedElement); // Add dragged element to the Set of the response field
    responseFields.set(draggedElement, optionsInField);
  }
}

// Attach event handlers for draggable options
var options = document.querySelectorAll('.option');
options.forEach(option => {
  option.addEventListener('dragstart', drag);
});

// Sample data for word list and option pool
var wordListData = [
  { translation: "Translation 1", kanji: "Kanji1", kana: "Kana1", id: "1"},
  { translation: "Translation 2", kanji: "Kanji2", kana: "Kana2", id: "2"},
  // Add more word list data as needed
];
    

// Function to initialize the word list
function initializeWordList() {
  console.log("static items: " + wordListContainer);
  
  // labels in forst column
  var labelContainer = document.createElement('div');
  var translationLabel = document.createElement('div');
  translationLabel.innerText = "Translation";
  var kanjiLabel = document.createElement('div');
  kanjiLabel.innerText = "Kanji";
  var kanaLabel = document.createElement('div');
  kanaLabel.innerText = "Kana"; 
  labelContainer.appendChild(translationLabel);
  labelContainer.appendChild(kanjiLabel);
  labelContainer.appendChild(kanaLabel);
  wordListContainer.appendChild(labelContainer);

  $scope.items.forEach(function(item) {
   	var item = $scope.item;
    console.log($scope.item);
    var wordItem = document.createElement('div');
    wordItem.classList.add('wordItem');

    var translation = document.createElement('div');
    translation.classList.add('translation');
    translation.textContent = item.translation;

    var kanjiResponse = document.createElement('div');
    kanjiResponse.classList.add('response');
    kanjiResponse.setAttribute('ondrop', 'drop(event)');
    kanjiResponse.setAttribute('ondragover', 'allowDrop(event)');
    kanjiResponse.maxChildren = 1;
    kanjiResponse.id = "responseKanji" + item.id;
    
    var kanaResponse = document.createElement('div');
    kanaResponse.classList.add('response');
    kanaResponse.setAttribute('ondrop', 'drop(event)');
    kanaResponse.setAttribute('ondragover', 'allowDrop(event)');
    kanaResponse.maxChildren = 1;
    kanaResponse.id = "responseKana" + item.id;

    wordItem.appendChild(translation);
    wordItem.appendChild(kanjiResponse);
    wordItem.appendChild(kanaResponse);
    wordListContainer.appendChild(wordItem);
  });
}

// Function to initialize the option pool
function initializeOptionPool() {
  // options can be dropped back into pool
  optionPoolContainer.setAttribute('ondrop', 'drop(event)');
  optionPoolContainer.setAttribute('ondragover', 'allowDrop(event)');
  optionPoolContainer.maxChildren = 100;
  var unmatchedOptionSet = new Set();
  console.log("initializing option pool");

  $scope.items.forEach(function(item) {
    var optionKanji = document.createElement('div');
    optionKanji.classList.add('option');
    optionKanji.draggable = 'true';
    optionKanji.id = 'optionKanji' + item.id;
    optionKanji.textContent = item.kanji;

    var optionKana = document.createElement('div');
    optionKana.classList.add('option');
    optionKana.draggable = 'true';
    optionKana.id = 'optionKana' + item.id;
    optionKana.textContent = item.kana;

    // Attach drag event listeners to options
    optionKanji.addEventListener('dragstart', drag);
    optionKana.addEventListener('dragstart', drag);

   	optionPoolContainer.appendChild(optionKanji);
    optionPoolContainer.appendChild(optionKana);
    unmatchedOptionSet = responseFields.get(optionPoolContainer, unmatchedOptionSet);
    unmatchedOptionSet.add(optionKanji);
    unmatchedOptionSet.add(optionKana);
  });
  responseFields.set(optionPoolContainer, unmatchedOptionSet);
}

// Call the initialization functions
initializeWordList();
initializeOptionPool();

// Function to initialize the response fields
function initializeResponseFields() {
  var responseFieldsElements = document.querySelectorAll('.response'); // Get all response field elements
  responseFieldsElements.forEach(function(responseField) {
    responseFields.set(responseField, new Set()); // Initialize a Set for each response field
  });
}

// Call the initialization function
initializeResponseFields();
*/
});
