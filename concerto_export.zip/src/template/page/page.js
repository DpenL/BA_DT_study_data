testRunner.controllerProvider.register("page", function($scope) {
  $scope.buttonLabel = testRunner.R.buttonLabel;
});
