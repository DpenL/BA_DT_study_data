testRunner.controllerProvider.register("header", function($scope) {
  $scope.title = testRunner.R.title;
  $scope.logo = testRunner.R.logo;
});
