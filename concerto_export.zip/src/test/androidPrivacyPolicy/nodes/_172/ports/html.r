<p>
	<strong>
		Privacy Policy for Dragon Tale
	</strong>
</p>

<p>
	Effective Date: July 10th 2024
</p>

<p>
	<strong>
		Introduction
	</strong>
</p>

<p>
	Welcome to Dragon Tale. Your privacy is important to us, and this Privacy Policy explains how we collect, use, and protect your information. By using our app, you agree to the practices described in this policy.
</p>

<p>
	<strong>
		Information We Collect
	</strong>
</p>

<ol>
	<li>
		<p>
			<strong>
				Usage Data
			</strong>
			:
		</p>

		<ul>
			<li>
				Our app collects usage data to help us understand how you interact with it. This data includes information about app features you use and the time spent on them.
			</li>
			<li>
				We cannot access this data directly. You must manually send it to us for analysis.
			</li>
		</ul>
	</li>
	<li>
		<p>
			<strong>
				Camera Usage
			</strong>
			:
		</p>

		<ul>
			<li>
				The app uses the camera for real-time Augmented Reality functionality.
			</li>
			<li>
				Captures are not saved or stored within the app or on any external servers.
			</li>
		</ul>
	</li>
</ol>

<p>
	<strong>
		How We Use Your Information
	</strong>
</p>

<ul>
	<li>
		The data you provide is used solely for the purpose of a scientific study aimed at improving our app's functionality and user experience.
	</li>
	<li>
		We do not share, sell, or distribute your information to third parties.
	</li>
</ul>

<p>
	<strong>
		Data Security
	</strong>
</p>

<p>
	We are committed to ensuring the security of your data. Any data sent to us is stored securely and used strictly within the confines of our scientific study.
</p>

<p>
	<strong>
		Your Consent
	</strong>
</p>

<p>
	By using our app, you consent to this Privacy Policy. If you do not agree with the terms, please do not use the app.
</p>

<p>
	<strong>
		Changes to This Privacy Policy
	</strong>
</p>

<p>
	We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.
</p>

<p>
	<strong>
		Contact Us
	</strong>
</p>

<p>
	If you have any questions about this Privacy Policy, please contact us at david.stiftl@tum.de
</p>

<p>
	<strong>
		Conclusion
	</strong>
</p>

<p>
	Your privacy and trust are important to us. We strive to protect your data and use it responsibly. Thank you for participating in our study and helping us improve Dragon Tale.
</p>
