params$envir = params
params$theta = theta
params$sem = sem
params$items = items
