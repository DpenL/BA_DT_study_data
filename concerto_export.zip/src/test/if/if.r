.branch = "false"
if(expression) { .branch = "true" }
