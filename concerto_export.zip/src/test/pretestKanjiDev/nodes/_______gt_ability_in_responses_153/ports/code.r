sql_query <- "
UPDATE pretestResponsesDev AS pr
JOIN pretestSessionsDev AS ps ON pr.session_id = CONCAT('i', ps.internal_id)
SET pr.ability = {{ability}}
WHERE ps.user_id = {{user_id}};
"

concerto.table.query(sql_query)
