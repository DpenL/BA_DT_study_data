sql_query <- "
UPDATE pretestUsersDev SET level = {{level}}, num_kanji = {{num_kanji}}, age = {{age}} WHERE id = {{user_id}}
"

concerto.table.query(sql_query)
