library(tidyr)
library(dplyr)
library(collections)

df <- data.frame(responses)
df <- df[!is.na(df$ability), ]
data <- df[,c('session_id','item_id','score')]

z1 <- df %>%
  group_by(session_id) %>%
  summarise(ability = unique(ability)) %>%
  pull(ability)

names(z1) <- df %>%
  group_by(session_id) %>%
  summarise(ability = unique(ability)) %>%
  pull(session_id)


head(data)


session_ids <- unique(df$session_id)
item_ids <- unique(df$item_id)


# save scores in map with keys (session/item)
# too dumb to do it smart atm
m <- dict()
for (session in session_ids) {
  for (item in item_ids) {
    score <- filter(df, session_id == session, item_id == item)$score
    
    m$set(list(session,item),score)  
    
  }    
}

result <- matrix(NA, nrow=length(session_ids), ncol=length(item_ids))
rownames(result) <- session_ids
colnames(result) <- item_ids


for (k in m$keys()) {
  session <- k[[1]]
  item <- k[[2]]
  
  score <- m$get(k)
  # Check if session and item are within the range of result dimensions
  if (!is.na(score) && length(score)) {
    # Update result at the corresponding index
    if (session %in% rownames(result) && item %in% colnames(result)) {
      result[which(rownames(result)==session),which(colnames(result)==item)] <- score
    }
  }
} 

#colnames(result) <- paste0("Item",item_ids)          


library(ltm)

#result <- descript(result,3,chi.squared=FALSE)
# RASCH 1PL model
model_rasch <- rasch(result, control=list(verbose=TRUE), IRT.param = TRUE)
item_params_rasch <- coef(model_rasch)
item.fit(model_rasch, G = 3, FUN = median, 
         simulate.p.value = FALSE, B = 100)
summary(model_rasch)
#plot(model_rasch)

# frame ground truth ability
z1 <- data.frame(z1)

result[is.na(result)] <- 0 # TODO get rid of this

# Fit a 2PL model
model_2pl <- ltm(result ~ z1, control=list(verbose=TRUE),IRT.param = TRUE)
item_params_2pl <- coef(model_2pl)
item.fit(model_2pl, G = 3, FUN = median, 
                   simulate.p.value = FALSE, B = 100)
#plot(model_2pl, type='IIC')


# fit 3 parameter model
model_3pl <- tpm(result)
item_params_3pl <- coef(model_3pl)
item.fit(model_3pl, G = 3, FUN = median, 
         simulate.p.value = FALSE, B = 100)
#plot(model_3pl, type='ICC')

# TODO repeat n>=10 times for global maximum