sql_query <- "
UPDATE pretestUsers SET level = {{level}}, num_kanji = {{num_kanji}}, age = {{age}}, gender = {{gender}} WHERE id = {{user_id}}
"

concerto.table.query(sql_query)
