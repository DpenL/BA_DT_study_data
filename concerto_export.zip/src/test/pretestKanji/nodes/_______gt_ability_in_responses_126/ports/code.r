sql_query <- "
UPDATE pretestResponses AS pr
JOIN pretestSessions AS ps ON pr.session_id = CONCAT('i', ps.internal_id)
SET pr.ability = {{ability}}
WHERE ps.user_id = {{user_id}};
"

concerto.table.query(sql_query)
