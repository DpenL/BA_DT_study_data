<p>
	Thank you for participating in the test, user {{user_id}}. Your scores in session {{session_id}} are as follows: 
	<br />
	Theta: {{theta}}
	<br />
	SEM: {{sem}}
</p>
