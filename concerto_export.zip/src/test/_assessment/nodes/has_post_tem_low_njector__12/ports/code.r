if(!is.null(postItemFlowInjector) && !is.na(postItemFlowInjector) && postItemFlowInjector != "") {
  .branch = "yes"
} else {
  .branch = "no"
}