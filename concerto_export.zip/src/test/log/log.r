for(.name in .dynamicInputs) {
  concerto.log(get(.name), .name)
}