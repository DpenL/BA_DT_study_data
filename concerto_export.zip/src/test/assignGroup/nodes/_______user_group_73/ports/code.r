sql_query <- "
UPDATE newUsers SET test_group = {{assigned_group}} WHERE id = {{user_id}}
"

concerto.table.query(sql_query)
