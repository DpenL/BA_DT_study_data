sql_query <- "
SELECT *
FROM demographics d
WHERE d.user_id = {{user_id}};
"

result <- concerto.table.query(sql_query)

print(result)
print(nrow(result))
print(typeof(!is.null(nrow(result)) && (nrow(result) >0)))