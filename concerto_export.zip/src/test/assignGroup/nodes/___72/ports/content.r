You have been assigned to group 
<strong>
	{{assigned_group}} 
</strong>
. Proceed to Download and happy gaming in AR!
