if (assigned_group == 1)
  .branch = 'AR'
if (assigned_group == 2)
  .branch = 'NOAR'
if (assigned_group == 3)
  .branch = 'NOGAME'
