print(group_sizes['user_count'])
result <- which.min(group_sizes$user_count) # assign to first group with min size -> Round Robin
#print(group_sizes[result])
