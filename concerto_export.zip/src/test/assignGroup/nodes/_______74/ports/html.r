<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
</title>
<h1>
	You have been assigned to group <bold>3</bold>.
</h1>

<p>
	As part of the control group, you play an important part in assessing the actual benefit of serious games. We hope you continue to have fun studying in a classical manner.
</p>
