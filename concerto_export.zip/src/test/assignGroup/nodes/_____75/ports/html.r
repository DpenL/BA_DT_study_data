<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
</title>
<style type="text/css">
body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #2c3e50;
        }
        h2 {
            color: #2980b9;
        }
        p {
            line-height: 1.6;
        }
        .section {
            margin-bottom: 30px;
        }
        .link {
            color: #3498db;
            text-decoration: none;
        }
        .link:hover {
            text-decoration: underline;
        }</style>
<h1>
	You have been assigned to group <bold>2 "Dragon Tale"</bold>.
</h1>

<div class="section">
	<h2>
		For iOS Testers
	</h2>

	<p>
		Delayed
	</p>
	<!--
	<ol>
		<li>
			Install the TestFlight app from the App Store: 
			<a class="link" href="https://apps.apple.com/us/app/testflight/id899247664" target="_blank">
				TestFlight on the App Store 
			</a>
		</li>
		<li>
			Open the TestFlight app and sign in with your Apple ID.
		</li>
		<li>
			Click on the following link to join the testing program: 
			<a class="link" href="https://testflight.apple.com/join/CEbivhcR" target="_blank">
				Join via TestFlight 
			</a>
		</li>
		<li>
			Follow the instructions in TestFlight to install the app.
		</li>
-->
</div>

<div class="section">
	<h2>
		For Android Testers
	</h2>

	<ol>
		<li>
			Join our Google Group: 
			<a class="link" href="https://groups.google.com/g/dragon-tale-testers" target="_blank">
				Join Google Group 
			</a>
			Click the button on the left to join.
		</li>
		<li>
			Once you have accepted to the group, click on the following link to get the invite to install the app: 
			<a class="link" href="https://play.google.com/apps/internaltest/4701137789697831598" target="_blank">
				Install the App 
			</a>
		</li>
		<li>
			Follow the instructions to download and install the app.
		</li>
	</ol>
</div>
<script>
        document.getElementById("downloadButton").addEventListener("click", function() {
            var fileUrl = '{{fileURL}}';
            var fileName = fileUrl.substring(fileUrl.lastIndexOf("/") + 1);

            var link = document.createElement("a");
            link.download = fileName;
            link.href = fileUrl;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    </script>