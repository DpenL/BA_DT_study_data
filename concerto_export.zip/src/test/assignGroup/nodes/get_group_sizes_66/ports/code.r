sql_query <- "
SELECT u.test_group, COUNT(d.course_level) AS user_count
FROM newUsers u
INNER JOIN demographics d ON u.id = d.user_id
WHERE d.course_level = {{course_level}} 
GROUP BY u.test_group;
"

group_counts = concerto.table.query(sql_query, params=list(
))
print(group_counts)


print(typeof(group_counts['test_group']))
print(length(group_counts['test_group' == 3]))

result <- group_counts
str(result)

# add empty groups
for (i in 1:3) {
  if (!(i %in% group_counts$test_group)) 
    result <- rbind(result, data.frame(test_group = i, user_count = 0))
}

# drop unassigned group
result <- result[!is.na(result$test_group), ]

# Sort the data frame by test_group
result <- result[order(result$test_group), ]

print(result)
