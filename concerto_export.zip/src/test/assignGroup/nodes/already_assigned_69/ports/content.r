You have already been assigned to group 
<strong>
	{{group}}
</strong>
