<p>
	This is a research project being conducted by David Stiftl at the Technical University of Munich in the context of a Bachelor Thesis. Each test should take approximately one hour of your time to complete.
</p>

<p>
	ABOUT THE STUDY
</p>

<p>
	This is a research project that aims to examine the impact of an interactive video game on learning Japanese characters. To achieve this, at two seperate points you will be asked to take a survey and test developed in the context of this Bachelor Thesis. You may also be asked to install a game application on your device and share information on your usage of the application with us.
</p>

<p>
	PARTICIPATION
</p>

<p>
	Your participation in this survey is voluntary and you may at any time refuse to take part in this research. In case you do wish to withdraw from the user study, please contact David Stiftl and let him know your wish to withdraw. You may freely decline to answer questions that feel uncomfortable to you. You are also free in how and how much you engage with the content offered by the application.
</p>

<p>
	RISKS
</p>

<p>
	There are no known foreseeable risks involved in participating in this study other than those encountered in day-to-day life. If there are any questions that make you feel uncomfortable, you may let us know that you intend to not answer those questions.
</p>

<p>
	DATA COLLECTION & CONFIDENTIALITY
</p>

<p>
	The information collected through the survey will be stored securely and confidentially. All data will be gathered through the online platform Concerto, where participants create a user account for this study. Access to the information is password protected and secured. I will not share your name, or any information that could personally identify you.
</p>

<p>
	CONTACT
</p>

<p>
	If you have any questions, you may get in touch with me any time at david.stiftl@tum.de. If you feel you have not been treated properly as to what this form describes, you may contact the ethics commission via website https://www.ek-med-muenchen.de.
</p>

<p>
	CONSENT
</p>

<p>
	 By checking the box below, I agree and affirm that:
</p>

<p>
	- I have read and understood the purpose of the information stated above.
</p>

<p>
	- I am 18 years of age or older.
</p>

<p>
	- I am submitting this form and participating in the project voluntarily and was not coerced, forced, threatened, or intimidated.
</p>
