<p>
	Thank you for participating in the test. You took {{total_time}} minutes.
</p>

<p>
	The test placed you at level {{prof_med}}.  We are confident that you fall within levels {{prof_low}} and {{prof_upp}}.
</p>

<p>
	Total questions: {{total_items}}
</p>

<p>
	Correct: {{total_correct}}
</p>

<p>
	Incorrect: {{total_incorrect}}
</p>

<p>
	Skipped: {{total_skipped}}
</p>

<p>
</p>
