library(jsonlite)

# Extract the access token
access_token <- responseBody$access_token
