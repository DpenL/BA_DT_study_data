library(htmltools)
library(shiny)

# Define the JavaScript code to retrieve the current URL
js_code <- "<script>var currentUrl = window.location.href;</script>"

# Create an HTML document with the JavaScript code embedded
html_document <- paste0("<!DOCTYPE html><html><head></head><body>", js_code, "</body></html>")

# Parse the HTML document
parsed_html <- htmltools::htmlTemplate(text_=html_document)
doc = htmltools::renderDocument(parsed_html)
print(doc)

# Extract the current URL from the JavaScript code
current_url <- xpathApply(parsed_html, "//script", xmlValue)[[1]]
print(current_url)
