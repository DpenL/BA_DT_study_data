library(dplyr)

interval <- 1.96 * sem

theta_levels <- c(-1.0, -0.5, 0.0, 0.5, 1.0, 100.0)
ability_levels <- c("Beginner", "A1.1", "A1.2", "A1.3", "A1.4", "A2+")

lower <- theta - interval
upper <- theta + interval

prof_med <- ""
prof_low <- ""
prof_high <- ""

for (i in 1:length(theta_levels)) {
  level <- theta_levels[i]
  if (theta < level) {
    prof_med <- ability_levels[i]
    break
  } else {
    prof_med <- ability_levels[i]
  }
}

for (i in 1:length(theta_levels)) {
  level <- theta_levels[i]
  if (lower < level) {
    prof_low <- ability_levels[i]
    break
  } else {
    prof_low <- ability_levels[i]
  }
}

for (i in 1:length(theta_levels)) {
  level <- theta_levels[i]
  if (upper < level) {
    prof_upp <- ability_levels[i]
    break
  } else {
    prof_upp <- ability_levels[i]
  }
}

# total time
sql_query <- "
SELECT timeTaken, score, skipped
FROM postResponses
WHERE session_id = '{{session_id}}'
"

responses <- concerto.table.query(sql_query)

total_items <- nrow(responses)
total_correct <- nrow(responses %>% filter(score == 1))
total_incorrect <- nrow(responses %>% filter(score == 0))
total_skipped <- nrow(responses %>% filter(skipped == TRUE))
total_time <- sum(responses$timeTaken) / 60.0
